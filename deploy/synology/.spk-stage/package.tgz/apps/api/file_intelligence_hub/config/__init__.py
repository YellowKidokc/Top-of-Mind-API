"""Centralized hub configuration."""
